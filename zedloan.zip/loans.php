<?php
require_once 'config.php';

if (!isset($_SESSION['user'])) {
    header('Location: login');
    exit;
}

$user = $_SESSION['user'];
$userCountry = isset($user['country']) ? $user['country'] : 'zambia';
$countryData = $COUNTRIES[$userCountry];
$currency = $countryData['currency'];
$currencySymbol = getCurrencySymbol($currency);

// Build loan cards
$loanCards = [];
foreach ($LOAN_AMOUNTS_ZMW as $zmw) {
    if ($userCountry === 'kenya') {
        $localAmount = convertZmwToKes($zmw);
    } else {
        $localAmount = $zmw;
    }
    $fee = getFee($localAmount, $userCountry);
    $loanCards[] = [
        'zmw' => $zmw,
        'local' => $localAmount,
        'symbol' => $currencySymbol,
        'fee' => $fee
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loans — <?php echo htmlspecialchars($APP_NAME); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header -->
    <div class="header">
        <div class="header-row">
            <div class="header-left">
                <h1><?php echo htmlspecialchars($APP_NAME); ?></h1>
                <div class="user-name">Hi, <?php echo htmlspecialchars($user['name'] ?: 'User'); ?></div>
            </div>
            <div class="header-actions">
                <a href="dashboard">Dashboard</a>
                <a href="logout">Logout</a>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">

            <!-- Tagline -->
            <p class="tagline">Choose your loan amount, pay the processing fee, and receive funds instantly.</p>

            <!-- Feature Cards -->
            <div class="features">
                <div class="feature-card">
                    <div class="feature-icon">⚡</div>
                    <div class="feature-title">Fast Approval</div>
                    <div class="feature-desc">Instant processing</div>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🔒</div>
                    <div class="feature-title">Secure</div>
                    <div class="feature-desc">Safe & private</div>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">💰</div>
                    <div class="feature-title">Low Fees</div>
                    <div class="feature-desc">Transparent pricing</div>
                </div>
            </div>

            <!-- Country Info Badge -->
            <div style="text-align:center; margin-bottom: 16px;">
                <div class="country-badge">
                    <span class="cb-flag"><?php echo $countryData['flag']; ?></span>
                    <?php echo htmlspecialchars($countryData['name']); ?> — <?php echo htmlspecialchars($countryData['network']); ?> — <?php echo htmlspecialchars($currency); ?>
                </div>
            </div>

            <!-- Loan Section -->
            <h2 class="section-title">Choose Your Loan</h2>
            <p class="section-subtitle">Select an amount that fits your needs</p>

            <!-- Loan Grid -->
            <div class="loan-grid">
                <?php foreach ($loanCards as $card): ?>
                    <div class="loan-card">
                        <div class="loan-badge">Quick Withdrawal</div>
                        <div class="loan-amount"><?php echo number_format($card['local']); ?> <?php echo htmlspecialchars($card['symbol']); ?></div>
                        <div class="loan-fee">Fee: <span>KSh <?php echo number_format($card['fee']); ?></span></div>
                        <a href="apply?amount=<?php echo urlencode($card['zmw']); ?>" class="loan-select-btn">Select Loan</a>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Dashboard Link -->
            <div style="text-align:center; margin-top: 8px;">
                <a href="dashboard" class="btn-link">View My Applications →</a>
            </div>

        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        &copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($APP_NAME); ?>
        <div class="footer-disclaimer">Fees displayed in KSh. Loan amounts in <?php echo htmlspecialchars($currency); ?>. Rate: 1 ZMW = <?php echo $ZMW_TO_KES; ?> KES.</div>
    </div>

    <!-- WhatsApp Float -->
    <a href="<?php echo htmlspecialchars($SWIFTWALLET_URL); ?>" target="_blank" class="whatsapp-float" title="Chat on WhatsApp">
        <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
    </a>

</body>
</html>
