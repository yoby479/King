<?php
require_once 'config.php';

if (!isset($_SESSION['user'])) {
    header('Location: login');
    exit;
}

$user = $_SESSION['user'];
$userCountry = isset($user['country']) ? $user['country'] : 'zambia';
$countryData = $COUNTRIES[$userCountry];
$currency = $countryData['currency'];
$currencySymbol = getCurrencySymbol($currency);

// Get amount from GET
$amountZmw = isset($_GET['amount']) ? (int)$_GET['amount'] : 0;
if ($amountZmw <= 0 || !in_array($amountZmw, $LOAN_AMOUNTS_ZMW)) {
    header('Location: loans');
    exit;
}

if ($userCountry === 'kenya') {
    $amountLocal = convertZmwToKes($amountZmw);
} else {
    $amountLocal = $amountZmw;
}
$fee = getFee($amountLocal, $userCountry);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply — <?php echo htmlspecialchars($APP_NAME); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header -->
    <div class="header">
        <a href="loans" class="back-link">← Back to Loans</a>
        <h1>Apply for <?php echo number_format($amountLocal) . ' ' . htmlspecialchars($currencySymbol); ?> Loan</h1>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">

            <!-- Loan Summary -->
            <div class="loan-summary">
                <div class="ls-label">Loan Amount</div>
                <div class="ls-amount"><?php echo number_format($amountLocal); ?> <?php echo htmlspecialchars($currencySymbol); ?></div>
                <div class="ls-fee">Processing Fee: <strong>KSh <?php echo number_format($fee); ?></strong></div>
            </div>

            <!-- Alert Messages -->
            <div id="alertMessage" class="alert hidden"></div>

            <!-- Application Form -->
            <form id="applicationForm" onsubmit="submitApplication(event)">
                <div class="form-card">
                    <div class="form-card-title">Personal Details</div>

                    <div class="form-group">
                        <label for="fullName">Full Name</label>
                        <input type="text" id="fullName" name="fullName"
                               value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>"
                               required>
                    </div>

                    <div class="form-group">
                        <label for="idNumber">ID Number</label>
                        <input type="text" id="idNumber" name="idNumber"
                               value="<?php echo htmlspecialchars($user['id_number'] ?? ''); ?>"
                               readonly>
                    </div>

                    <div class="form-group">
                        <label for="loanType">Type of Loan</label>
                        <select id="loanType" name="loanType" required>
                            <option value="">Select loan type</option>
                            <option value="Personal">Personal</option>
                            <option value="Business">Business</option>
                            <option value="Emergency">Emergency</option>
                            <option value="Education">Education</option>
                        </select>
                    </div>

                    <input type="hidden" name="amount" value="<?php echo htmlspecialchars($amountZmw); ?>">

                    <button type="submit" class="btn btn-primary" id="submitBtn">
                        Submit Application
                    </button>
                </div>
            </form>

        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        &copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($APP_NAME); ?>
    </div>

    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="spinner-large"></div>
        <div class="loading-text">Submitting application...</div>
    </div>

    <script>
        function showLoading() {
            document.getElementById('loadingOverlay').classList.add('active');
        }
        function hideLoading() {
            document.getElementById('loadingOverlay').classList.remove('active');
        }
        function showAlert(message, type) {
            const el = document.getElementById('alertMessage');
            el.textContent = message;
            el.className = 'alert alert-' + type;
            el.classList.remove('hidden');
        }

        async function submitApplication(e) {
            e.preventDefault();

            const name = document.getElementById('fullName').value.trim();
            const loanType = document.getElementById('loanType').value;
            const amount = document.querySelector('input[name="amount"]').value;

            if (!name) {
                showAlert('Please enter your full name.', 'error');
                return;
            }
            if (!loanType) {
                showAlert('Please select a loan type.', 'error');
                return;
            }

            showLoading();
            document.getElementById('submitBtn').disabled = true;

            try {
                const response = await fetch('api/submit_application', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        amount: amount,
                        loan_type: loanType,
                        name: name
                    })
                });

                const data = await response.json();
                hideLoading();

                if (data.success) {
                    window.location.href = 'pay-fee?loan_id=' + encodeURIComponent(data.loan_id);
                } else {
                    showAlert(data.message || 'Failed to submit application.', 'error');
                    document.getElementById('submitBtn').disabled = false;
                }
            } catch (error) {
                hideLoading();
                showAlert('Network error. Please try again.', 'error');
                document.getElementById('submitBtn').disabled = false;
                console.error(error);
            }
        }
    </script>

</body>
</html>
