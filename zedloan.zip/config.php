<?php
// Firebase Config (passed to frontend for email/password auth)
$FIREBASE_CONFIG = [
    'apiKey' => 'AIzaSyC2RduTONmVUWcdLJtYhg-ZkXWEXIhZAvo',
    'authDomain' => 'trade-ff4a4.firebaseapp.com',
    'projectId' => 'trade-ff4a4',
    'storageBucket' => 'trade-ff4a4.firebasestorage.app',
    'messagingSenderId' => '1084019484887',
    'appId' => '1:1084019484887:web:215f81e1859b86b6a56892',
    'measurementId' => 'G-8MKSCMVYF1'
];

$SW_API_KEY = 'sw_debee621eb3c04413149a47c97d649114cfcb2eb6f3bb13d0be8a65d';
$SW_API_URL = 'https://swiftwallet.co.ke/v3/stk-initiate/';
$SWIFTWALLET_URL = 'mailto:zambialoan@loans.com';

$COUNTRIES = [
    'zambia' => ['code' => '260', 'currency' => 'ZMW', 'network' => 'MTN', 'flag' => '🇿🇲', 'name' => 'Zambia'],
    'kenya'  => ['code' => '254', 'currency' => 'KES', 'network' => 'Safaricom', 'flag' => '🇰🇪', 'name' => 'Kenya']
];

$ZMW_TO_KES = 6;

$LOAN_AMOUNTS_ZMW = [500, 1000, 1500, 2000, 2500, 3000, 3500, 3800, 4500, 5000, 6000, 7500, 8000, 10000, 12000, 15000];

// Custom Kenya fees (keyed by KSh amount)
$KENYA_FEES = [
    3000 => 200,
    6000 => 389,
    9000 => 503,
    12000 => 1290,
    15000 => 1499,
    18000 => 1683,
    21000 => 1901,
    22800 => 2105,
    27000 => 2308,
    30000 => 2580,
    36000 => 2799,
    45000 => 3112,
    48000 => 3201,
    60000 => 3309,
    72000 => 5100,
    90000 => 8329
];

$FEE_PERCENT_ZAMBIA = 10;
$APP_NAME = 'ZamLoans';
$USERS_FILE = __DIR__ . '/data/users.json';
$LOANS_FILE = __DIR__ . '/data/loans.json';
$LOG_FILE = __DIR__ . '/data/callback_log.txt';

if (!file_exists($USERS_FILE)) file_put_contents($USERS_FILE, '[]');
if (!file_exists($LOANS_FILE)) file_put_contents($LOANS_FILE, '[]');
if (!file_exists(dirname($LOG_FILE))) mkdir(dirname($LOG_FILE), 0777, true);
if (!file_exists($LOG_FILE)) file_put_contents($LOG_FILE, '');

function getUsers() { global $USERS_FILE; return json_decode(file_get_contents($USERS_FILE), true) ?: []; }
function saveUsers($d) { global $USERS_FILE; file_put_contents($USERS_FILE, json_encode($d, JSON_PRETTY_PRINT)); }
function getLoans() { global $LOANS_FILE; return json_decode(file_get_contents($LOANS_FILE), true) ?: []; }
function saveLoans($d) { global $LOANS_FILE; file_put_contents($LOANS_FILE, json_encode($d, JSON_PRETTY_PRINT)); }
function convertZmwToKes($zmw) { global $ZMW_TO_KES; return round($zmw * $ZMW_TO_KES); }
function getFee($amount_local, $country) {
    global $KENYA_FEES, $FEE_PERCENT_ZAMBIA, $ZMW_TO_KES;
    if ($country === 'kenya') {
        return isset($KENYA_FEES[$amount_local]) ? $KENYA_FEES[$amount_local] : round($amount_local * 0.1);
    }
    // Zambia: 10% of ZMW, converted to KSh
    return round(($amount_local * $FEE_PERCENT_ZAMBIA / 100) * $ZMW_TO_KES);
}
function getCurrencySymbol($cur) { return $cur === 'KES' ? 'KSh' : 'ZMW'; }
function genId($pfx = 'ZL') { return $pfx . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8)); }
function logCallback($msg) { global $LOG_FILE; file_put_contents($LOG_FILE, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND); }

session_start();
?>
