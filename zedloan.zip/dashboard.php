<?php
require_once 'config.php';

if (!isset($_SESSION['user'])) {
    header('Location: login');
    exit;
}

$user = $_SESSION['user'];
$userEmail = $user['email'] ?? '';
$userCountry = $user['country'] ?? 'zambia';
$countryData = $COUNTRIES[$userCountry];

// Get user's loans
$allLoans = getLoans();
$userLoans = [];
foreach ($allLoans as $loan) {
    if (isset($loan['user_email']) && $loan['user_email'] === $userEmail) {
        $userLoans[] = $loan;
    }
}
$userLoans = array_values(array_reverse($userLoans));

// Calculate stats
$totalBalance = 0;
$activeLoans = 0;
$totalBorrowed = 0;
foreach ($userLoans as $loan) {
    if ($loan['status'] === 'approved') {
        $activeLoans++;
        $totalBalance += (int)($loan['amount_local'] ?? 0);
    }
    if ($loan['status'] === 'withdrawn') {
        $totalBorrowed += (int)($loan['amount_local'] ?? 0);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — <?php echo htmlspecialchars($APP_NAME); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header -->
    <div class="header">
        <div class="header-row">
            <div class="header-left">
                <h1>My Dashboard</h1>
                <div class="user-name">Hi, <?php echo htmlspecialchars($user['name'] ?: 'User'); ?></div>
            </div>
            <div class="header-actions">
                <a href="loans">Loans</a>
                <a href="logout">Logout</a>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card stat-green">
                    <div class="stat-icon">💵</div>
                    <div class="stat-value">KSh <?php echo number_format($totalBalance); ?></div>
                    <div class="stat-label">Total Balance</div>
                </div>
                <div class="stat-card stat-blue">
                    <div class="stat-icon">📋</div>
                    <div class="stat-value"><?php echo $activeLoans; ?></div>
                    <div class="stat-label">Active Loans</div>
                </div>
                <div class="stat-card stat-purple">
                    <div class="stat-icon">🏦</div>
                    <div class="stat-value">KSh <?php echo number_format($totalBorrowed); ?></div>
                    <div class="stat-label">Total Borrowed</div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="quick-actions">
                <a href="loans" class="btn btn-primary">Apply for New Loan</a>
                <a href="#loanList" class="btn btn-secondary">View All Loans</a>
            </div>

            <!-- Alert Messages -->
            <?php if (isset($_GET['withdrawn'])): ?>
                <div class="alert alert-success">Withdrawal successful! Funds sent to your M-Pesa.</div>
            <?php endif; ?>
            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($_GET['error']); ?></div>
            <?php endif; ?>

            <!-- Recent Applications -->
            <h2 class="section-title" id="loanList">Recent Applications</h2>
            <p class="section-subtitle">Track the status of your loan applications</p>

            <?php if (empty($userLoans)): ?>
                <div class="empty-state">
                    <div class="empty-icon">📋</div>
                    <p class="empty-text">No loans yet</p>
                    <a href="loans" class="empty-link">Browse Available Loans →</a>
                </div>
            <?php else: ?>
                <?php foreach ($userLoans as $loan):
                    $status = $loan['status'] ?? 'pending';
                    $statusLabel = str_replace('_', ' ', ucfirst($status));
                    $badgeClass = 'badge-' . $status;
                    if (!in_array($status, ['pending_payment', 'approved', 'withdrawn', 'failed'])) {
                        $badgeClass = 'badge-pending';
                    }
                    $currencySymbol = getCurrencySymbol($loan['currency'] ?? 'ZMW');
                    $date = isset($loan['created_at']) ? date('M j, Y g:i A', strtotime($loan['created_at'])) : 'N/A';
                    $loanType = htmlspecialchars($loan['loan_type'] ?? 'Personal');
                    $showWithdraw = ($status === 'approved');
                ?>
                    <div class="app-card">
                        <div class="app-header">
                            <div class="app-amount"><?php echo number_format($loan['amount_local'] ?? 0); ?> <?php echo htmlspecialchars($currencySymbol); ?></div>
                            <span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars($statusLabel); ?></span>
                        </div>
                        <div class="app-details">
                            <span class="app-type"><?php echo $loanType; ?> • <?php echo htmlspecialchars($loan['id']); ?></span>
                            <span class="app-date"><?php echo $date; ?></span>
                        </div>
                        <div class="app-fee">Fee Paid: KSh <?php echo number_format($loan['fee'] ?? 0); ?></div>
                        <?php if ($showWithdraw): ?>
                            <div class="app-actions">
                                <button type="button" class="btn btn-primary btn-sm" onclick="showWithdrawModal('<?php echo htmlspecialchars($loan['id']); ?>', <?php echo (int)($loan['amount_local'] ?? 0); ?>)">
                                    Withdraw Now
                                </button>
                            </div>
                        <?php endif; ?>
                        <?php if ($status === 'pending_payment'): ?>
                            <div class="app-actions">
                                <a href="pay-fee?loan_id=<?php echo urlencode($loan['id']); ?>" class="btn btn-primary btn-sm">
                                    Pay Fee
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

        </div>
    </div>

    <!-- Withdrawal Modal -->
    <div class="modal-overlay" id="withdrawModal">
        <div class="modal-card">
            <div class="modal-icon">💸</div>
            <div class="modal-title">Confirm Withdrawal</div>
            <div class="modal-amount" id="withdrawAmount">KSh 0</div>
            <div class="modal-text">Withdraw to your M-Pesa account? This action cannot be undone.</div>
            <div id="withdrawError" class="alert alert-error hidden" style="margin-bottom:12px;"></div>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" onclick="hideWithdrawModal()">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmWithdrawBtn" onclick="confirmWithdraw()">Confirm</button>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        &copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($APP_NAME); ?>
    </div>

    <!-- WhatsApp Float -->
    <a href="<?php echo htmlspecialchars($SWIFTWALLET_URL); ?>" target="_blank" class="whatsapp-float" title="Chat on WhatsApp">
        <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
    </a>

    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="spinner-large"></div>
        <div class="loading-text" id="loadingText">Processing...</div>
    </div>

    <script>
        let currentWithdrawLoanId = '';

        function showWithdrawModal(loanId, amount) {
            currentWithdrawLoanId = loanId;
            document.getElementById('withdrawAmount').textContent = 'KSh ' + amount.toLocaleString();
            document.getElementById('withdrawError').classList.add('hidden');
            document.getElementById('confirmWithdrawBtn').disabled = false;
            document.getElementById('withdrawModal').classList.add('active');
        }

        function hideWithdrawModal() {
            document.getElementById('withdrawModal').classList.remove('active');
            currentWithdrawLoanId = '';
        }

        function showLoading(text) {
            document.getElementById('loadingText').textContent = text || 'Processing...';
            document.getElementById('loadingOverlay').classList.add('active');
        }
        function hideLoading() {
            document.getElementById('loadingOverlay').classList.remove('active');
        }

        async function confirmWithdraw() {
            if (!currentWithdrawLoanId) return;

            const btn = document.getElementById('confirmWithdrawBtn');
            const errorEl = document.getElementById('withdrawError');
            btn.disabled = true;
            showLoading('Processing withdrawal...');

            try {
                const resp = await fetch('api/withdraw', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        loan_id: currentWithdrawLoanId
                    })
                });

                const data = await resp.json();
                hideLoading();

                if (data.success) {
                    hideWithdrawModal();
                    window.location.href = 'dashboard?withdrawn=1';
                } else {
                    errorEl.textContent = data.message || 'Withdrawal failed.';
                    errorEl.classList.remove('hidden');
                    btn.disabled = false;
                }
            } catch (err) {
                hideLoading();
                errorEl.textContent = 'Network error. Please try again.';
                errorEl.classList.remove('hidden');
                btn.disabled = false;
                console.error(err);
            }
        }

        // Close modal on overlay click
        document.getElementById('withdrawModal').addEventListener('click', function(e) {
            if (e.target === this) hideWithdrawModal();
        });
    </script>

</body>
</html>
