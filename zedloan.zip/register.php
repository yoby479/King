<?php require_once 'config.php';

$country = isset($_GET['country']) ? $_GET['country'] : 'zambia';
if (!isset($COUNTRIES[$country])) $country = 'zambia';
$countryData = $COUNTRIES[$country];

if (isset($_SESSION['user'])) {
    header('Location: loans');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Register — <?php echo htmlspecialchars($APP_NAME); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="header">
    <a href="index" class="back-link">&larr; Back</a>
    <h1>Create Account</h1>
</div>

<div class="main-content">
    <div class="container">

        <div class="country-selector">
            <span class="flag"><?php echo $countryData['flag']; ?></span>
            <span class="country-label"><?php echo htmlspecialchars($countryData['name']); ?> — <?php echo htmlspecialchars($countryData['network']); ?></span>
        </div>

        <form id="registerForm" onsubmit="registerUser(event)">
            <div class="form-card">
                <div class="form-card-title">Create Your Account</div>

                <div class="form-group">
                    <label for="fullName">Full Names</label>
                    <input type="text" id="fullName" placeholder="e.g. John Banda" required>
                </div>

                <div class="form-group">
                    <label for="emailInput">Email Address</label>
                    <input type="email" id="emailInput" placeholder="e.g. john@email.com" required>
                </div>

                <div class="form-group">
                    <label for="idNumber">National ID Number</label>
                    <input type="text" id="idNumber" placeholder="e.g. 12345678" required>
                </div>

                <div class="form-group">
                    <label for="dobInput">Date of Birth</label>
                    <input type="date" id="dobInput" required>
                </div>

                <div class="form-group">
                    <label for="passwordInput">Password</label>
                    <input type="password" id="passwordInput" placeholder="Minimum 6 characters" minlength="6" required>
                </div>

                <div class="form-group">
                    <label for="confirmPasswordInput">Confirm Password</label>
                    <input type="password" id="confirmPasswordInput" placeholder="Re-enter your password" required>
                </div>

                <div id="regError" class="alert alert-error hidden"></div>

                <button type="submit" class="btn btn-primary" id="registerBtn">
                    Create Account
                </button>
            </div>
        </form>

        <div class="divider">or</div>
        <a href="login" class="btn-link">Already have an account? Login</a>

    </div>
</div>

<div class="loading-overlay" id="loadingOverlay">
    <div class="spinner-large"></div>
    <div class="loading-text" id="loadingText">Creating account...</div>
</div>

<!-- Firebase SDK v12.8.0 Modular -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-auth.js";

const firebaseConfig = <?php echo json_encode($FIREBASE_CONFIG); ?>;
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const country = '<?php echo addslashes($country); ?>';

function showLoading(text) {
    document.getElementById('loadingText').textContent = text || 'Loading...';
    document.getElementById('loadingOverlay').classList.add('active');
}
function hideLoading() {
    document.getElementById('loadingOverlay').classList.remove('active');
}
function showError(msg) {
    const el = document.getElementById('regError');
    el.textContent = msg;
    el.classList.remove('hidden');
}

window.registerUser = async function(e) {
    e.preventDefault();

    const name = document.getElementById('fullName').value.trim();
    const email = document.getElementById('emailInput').value.trim();
    const idNumber = document.getElementById('idNumber').value.trim();
    const dob = document.getElementById('dobInput').value;
    const password = document.getElementById('passwordInput').value;
    const confirmPassword = document.getElementById('confirmPasswordInput').value;

    if (!name || !email || !idNumber || !dob || !password || !confirmPassword) {
        showError('All fields are required.');
        return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showError('Please enter a valid email address.');
        return;
    }
    if (password.length < 6) {
        showError('Password must be at least 6 characters.');
        return;
    }
    if (password !== confirmPassword) {
        showError('Passwords do not match.');
        return;
    }

    showError('');
    showLoading('Creating account with Firebase...');
    document.getElementById('registerBtn').disabled = true;

    try {
        // 1. Create Firebase account
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const uid = userCredential.user.uid;
        const firebaseEmail = userCredential.user.email;

        // 2. Save user data to PHP backend
        showLoading('Saving your details...');
        const formData = new FormData();
        formData.append('action', 'register');
        formData.append('uid', uid);
        formData.append('name', name);
        formData.append('email', firebaseEmail);
        formData.append('id_number', idNumber);
        formData.append('dob', dob);
        formData.append('country', country);

        const resp = await fetch('api/check_auth', {
            method: 'POST',
            body: formData
        });
        const data = await resp.json();
        hideLoading();

        if (data.success) {
            window.location.href = 'login?registered=1';
        } else {
            showError(data.message || 'Registration failed. Please try again.');
            document.getElementById('registerBtn').disabled = false;
        }
    } catch (error) {
        hideLoading();
        let msg = 'Registration failed. Please try again.';
        if (error.code === 'auth/email-already-in-use') msg = 'This email is already registered. Please login.';
        else if (error.code === 'auth/weak-password') msg = 'Password is too weak. Use at least 6 characters.';
        else if (error.code === 'auth/invalid-email') msg = 'Invalid email address.';
        else if (error.code === 'auth/network-request-failed') msg = 'Network error. Check your internet connection.';
        showError(msg);
        document.getElementById('registerBtn').disabled = false;
        console.error(error);
    }
};
</script>

</body>
</html>
