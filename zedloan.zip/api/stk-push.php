<?php
require_once dirname(__DIR__) . '/config.php';
header('Content-Type: application/json');

// Read JSON body (PHP $_POST does NOT work with JSON payloads!)
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = [];

$loan_id = trim($input['loan_id'] ?? '');
$phone = trim($input['phone_number'] ?? '');

if (!$loan_id || !$phone) {
    echo json_encode(['success' => false, 'message' => 'Missing fields']);
    exit;
}

$loans = getLoans();
$loan = null;
$loanIndex = -1;
foreach ($loans as $i => &$l) {
    if ($l['id'] === $loan_id) {
        $loan = &$l;
        $loanIndex = $i;
        break;
    }
}
unset($l);

if (!$loan) {
    echo json_encode(['success' => false, 'message' => 'Loan not found']);
    exit;
}

if ($loan['status'] === 'approved' || $loan['status'] === 'withdrawn') {
    echo json_encode(['success' => false, 'message' => 'Loan already processed']);
    exit;
}

// Format phone to 254XXXXXXXXX format (SwiftWallet v3 accepts 07XXXXXXXX too)
$phone = preg_replace('/[^0-9]/', '', $phone);
if (strlen($phone) === 10 && $phone[0] === '0') $phone = substr($phone, 1); // 0795... -> 795...
// SwiftWallet v3 accepts both "254XXXXXXXXX" and "07XXXXXXXX"
// Let's use the 07XXXXXXXX format since that's what the docs show
if (strlen($phone) === 9 && ($phone[0] === '7' || $phone[0] === '1')) $phone = '0' . $phone;

$external_reference = 'ZL-' . $loan_id . '-' . time();
$callback_url = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/webhook.php?loan_id=' . urlencode($loan_id);

// SwiftWallet v3 STK Push
$payload = [
    'amount' => (int)$loan['fee'],
    'phone_number' => $phone,
    'external_reference' => $external_reference,
    'callback_url' => $callback_url
];

logCallback("STK Push v3 for $loan_id (phone=$phone, amount=" . $loan['fee'] . "): " . json_encode($payload));

$ch = curl_init($SW_API_URL);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $SW_API_KEY
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

$result = json_decode($response, true);
logCallback("STK Push response: HTTP $http_code - " . $response . ($curl_error ? " cURL Error: $curl_error" : ""));

if ($http_code == 200 && isset($result['success']) && $result['success'] === true) {
    $loans[$loanIndex]['status'] = 'pending_payment';
    $loans[$loanIndex]['phone'] = $phone;
    $loans[$loanIndex]['reference'] = $external_reference;
    $loans[$loanIndex]['stk_transaction_id'] = $result['transaction_id'] ?? null;
    $loans[$loanIndex]['checkout_request_id'] = $result['checkout_request_id'] ?? null;
    saveLoans($loans);
    echo json_encode(['success' => true, 'message' => 'STK Push sent! Check your phone and enter your M-Pesa PIN.']);
} else {
    $errorMsg = $result['error'] ?? $result['message'] ?? 'Payment initiation failed';
    if ($http_code === 0) $errorMsg = 'Could not connect to payment provider. Please try again.';
    if ($http_code === 401) $errorMsg = 'Payment API key error. Please contact support.';
    if ($http_code === 402) $errorMsg = 'Service balance insufficient. Please contact support.';
    if ($http_code === 429) $errorMsg = 'Rate limit exceeded. Please wait and try again.';
    echo json_encode(['success' => false, 'message' => $errorMsg]);
}
