<?php
require_once dirname(__DIR__) . '/config.php';
header('Content-Type: application/json');

// session_start already called in config.php

if (!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$loan_id = trim($input['loan_id'] ?? '');

if (!$loan_id) {
    echo json_encode(['success' => false, 'message' => 'Missing loan ID']);
    exit;
}

$user = $_SESSION['user'];
$userEmail = $user['email'] ?? '';

$loans = getLoans();
$found = false;
$loanIndex = -1;

foreach ($loans as $i => $loan) {
    if ($loan['id'] === $loan_id && $loan['user_email'] === $userEmail) {
        $found = true;
        $loanIndex = $i;
        break;
    }
}

if (!$found) {
    echo json_encode(['success' => false, 'message' => 'Loan not found']);
    exit;
}

if ($loans[$loanIndex]['status'] !== 'approved') {
    echo json_encode(['success' => false, 'message' => 'Loan is not approved for withdrawal']);
    exit;
}

// Process withdrawal
$amount = (int)$loans[$loanIndex]['amount_local'];
$loans[$loanIndex]['status'] = 'withdrawn';
$loans[$loanIndex]['withdrawn_at'] = date('Y-m-d H:i:s');

// Update user balance
$users = getUsers();
foreach ($users as &$u) {
    if ($u['email'] === $userEmail) {
        $u['balance'] = (int)($u['balance'] ?? 0) + $amount;
        $_SESSION['user'] = $u;
        break;
    }
}
unset($u);
saveUsers($users);
saveLoans($loans);

logCallback("WITHDRAWN: Loan $loan_id - KSh $amount withdrawn by $userEmail");

echo json_encode([
    'success' => true,
    'message' => 'Withdrawal successful',
    'amount' => $amount
]);
