<?php
require_once dirname(__DIR__) . '/config.php';
header('Content-Type: application/json');

$loan_id = $_GET['id'] ?? '';
if (!$loan_id) {
    echo json_encode(['success' => false, 'message' => 'Missing loan ID']);
    exit;
}

$loans = getLoans();
foreach ($loans as $loan) {
    if ($loan['id'] === $loan_id) {
        echo json_encode([
            'success' => true,
            'status' => $loan['status'],
            'amount' => $loan['amount_local'],
            'fee' => $loan['fee']
        ]);
        exit;
    }
}

echo json_encode(['success' => false, 'message' => 'Loan not found']);
