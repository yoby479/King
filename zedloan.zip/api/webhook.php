<?php
require_once dirname(__DIR__) . '/config.php';
header('Content-Type: application/json');

// Get raw POST body
$body = file_get_contents('php://input');
$data = json_decode($body, true);
if (!$data) $data = [];

logCallback("Webhook received: " . $body);

// SwiftWallet v3 callback format:
// {
//   "success": true/false,
//   "status": "completed"/"failed",
//   "result": { "ResultCode": 0, "ResultDesc": "...", "MpesaReceiptNumber": "...", ... },
//   "external_reference": "...",
//   "transaction_id": 12345
// }

$status = $data['status'] ?? 'unknown';
$result_code = $data['result']['ResultCode'] ?? -1;
$external_ref = $data['external_reference'] ?? '';
$transaction_id = $data['transaction_id'] ?? '';

// Get loan_id from query string
$loan_id = $_GET['loan_id'] ?? '';

// Fallback: extract loan_id from external_reference (format: ZL-XXXXXXXX-digits)
if (!$loan_id && $external_ref) {
    $m = [];
    if (preg_match('/ZL-([A-F0-9]{8})-\d+/', $external_ref, $m)) {
        $loan_id = $m[1];
    }
}

if (!$loan_id) {
    logCallback("Webhook: No loan_id found (ext_ref=$external_ref)");
    echo json_encode(['status' => 'received']);
    exit;
}

$loans = getLoans();
$found = false;
foreach ($loans as &$loan) {
    if ($loan['id'] === $loan_id) {
        $found = true;
        
        // SwiftWallet v3: status="completed" OR result.ResultCode=0 means success
        if ($status === 'completed' || $result_code == 0) {
            $loan['status'] = 'approved';
            $loan['approved_at'] = date('Y-m-d H:i:s');
            $loan['mpesa_receipt'] = $data['result']['MpesaReceiptNumber'] ?? null;
            $loan['sw_transaction_id'] = $transaction_id;
            logCallback("APPROVED: Loan $loan_id - Fee paid (tx=$transaction_id), loan approved");
        } else {
            // Payment failed or cancelled
            $loan['status'] = 'pending_payment'; // Reset so user can retry
            $fail_reason = $data['result']['ResultDesc'] ?? 'Payment failed or cancelled';
            $loan['last_fail_reason'] = $fail_reason;
            $loan['last_fail_at'] = date('Y-m-d H:i:s');
            logCallback("FAILED: Loan $loan_id - $fail_reason (tx=$transaction_id)");
        }
        break;
    }
}
unset($loan);

if ($found) {
    saveLoans($loans);
}

echo json_encode(['status' => 'received', 'loan_id' => $loan_id]);
