<?php
require_once dirname(__DIR__) . '/config.php';
header('Content-Type: application/json');

// session_start already called in config.php

if (!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$amount_zmw = (int)($input['amount'] ?? 0);
$loan_type = trim($input['loan_type'] ?? '');
$name = trim($input['name'] ?? '');

$user = $_SESSION['user'];
$userCountry = $user['country'] ?? 'zambia';
$countryData = $COUNTRIES[$userCountry];
$currency = $countryData['currency'];

if ($amount_zmw <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid loan amount']);
    exit;
}

if (!in_array($amount_zmw, $LOAN_AMOUNTS_ZMW)) {
    echo json_encode(['success' => false, 'message' => 'Invalid loan amount']);
    exit;
}

if (!$loan_type) {
    echo json_encode(['success' => false, 'message' => 'Please select a loan type']);
    exit;
}

// Calculate local amount and fee
if ($userCountry === 'kenya') {
    $amount_local = convertZmwToKes($amount_zmw);
} else {
    $amount_local = $amount_zmw;
}
$fee = getFee($amount_local, $userCountry);

// Create loan
$loan_id = genId('ZL');
$loan = [
    'id' => $loan_id,
    'user_email' => $user['email'] ?? '',
    'user_name' => $name ?: $user['name'],
    'country' => $userCountry,
    'amount_zmw' => $amount_zmw,
    'amount_local' => $amount_local,
    'currency' => $currency,
    'fee' => $fee,
    'loan_type' => $loan_type,
    'status' => 'pending_payment',
    'created_at' => date('Y-m-d H:i:s')
];

$loans = getLoans();
$loans[] = $loan;
saveLoans($loans);

echo json_encode([
    'success' => true,
    'message' => 'Application submitted',
    'loan_id' => $loan_id
]);
