<?php
require_once dirname(__DIR__) . '/config.php';
header('Content-Type: application/json');

// session_start already called in config.php

if (!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$user = $_SESSION['user'];
$userEmail = $user['email'] ?? '';

$loans = getLoans();
$userLoans = [];
foreach ($loans as $loan) {
    if (isset($loan['user_email']) && $loan['user_email'] === $userEmail) {
        $userLoans[] = $loan;
    }
}

// Return reversed (newest first)
echo json_encode(['success' => true, 'loans' => array_reverse($userLoans)]);
