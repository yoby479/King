<?php
require_once dirname(__DIR__) . '/config.php';
header('Content-Type: application/json');

$action = $_POST['action'] ?? '';
$users = getUsers();

if ($action === 'register') {
    $uid = trim($_POST['uid'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $id_number = trim($_POST['id_number'] ?? '');
    $dob = trim($_POST['dob'] ?? '');
    $country = trim($_POST['country'] ?? 'zambia');

    if (!$uid || !$name || !$email) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
        exit;
    }

    // Check if user already exists by uid or email
    foreach ($users as $u) {
        if (isset($u['uid']) && $u['uid'] === $uid) {
            // Update existing user data
            foreach ($users as &$uu) {
                if ($uu['uid'] === $uid) {
                    $uu['name'] = htmlspecialchars($name);
                    $uu['email'] = $email;
                    $uu['id_number'] = htmlspecialchars($id_number);
                    $uu['dob'] = htmlspecialchars($dob);
                    $uu['country'] = $country;
                    break;
                }
            }
            unset($uu);
            saveUsers($users);
            echo json_encode(['success' => true, 'message' => 'Account created successfully!']);
            exit;
        }
    }

    // Create new user
    $users[] = [
        'id' => genId('USR'),
        'uid' => $uid,
        'name' => htmlspecialchars($name),
        'email' => $email,
        'id_number' => htmlspecialchars($id_number),
        'dob' => htmlspecialchars($dob),
        'country' => $country,
        'phone' => '',
        'created_at' => date('Y-m-d H:i:s')
    ];
    saveUsers($users);
    echo json_encode(['success' => true, 'message' => 'Account created successfully!']);
    exit;
}

if ($action === 'login') {
    $uid = trim($_POST['uid'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));

    if (!$uid || !$email) {
        echo json_encode(['success' => false, 'message' => 'Missing authentication data.']);
        exit;
    }

    // Find user by uid
    $found = false;
    foreach ($users as $u) {
        if (isset($u['uid']) && $u['uid'] === $uid) {
            $_SESSION['user'] = $u;
            $found = true;
            break;
        }
    }

    if (!$found) {
        // User authenticated via Firebase but not in our DB — create record
        $newUser = [
            'id' => genId('USR'),
            'uid' => $uid,
            'name' => explode('@', $email)[0],
            'email' => $email,
            'id_number' => '',
            'dob' => '',
            'country' => 'zambia',
            'phone' => '',
            'created_at' => date('Y-m-d H:i:s')
        ];
        $users[] = $newUser;
        saveUsers($users);
        $_SESSION['user'] = $newUser;
    }

    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action.']);
