<?php
require_once 'config.php';

if (!isset($_SESSION['user'])) {
    header('Location: login');
    exit;
}

$user = $_SESSION['user'];
$loan_id = isset($_GET['loan_id']) ? htmlspecialchars($_GET['loan_id']) : '';

if (!$loan_id) {
    header('Location: loans');
    exit;
}

// Look up loan
$loans = getLoans();
$loan = null;
foreach ($loans as $l) {
    if ($l['id'] === $loan_id) {
        $loan = $l;
        break;
    }
}

if (!$loan) {
    header('Location: loans');
    exit;
}

$currencySymbol = getCurrencySymbol($loan['currency']);
$loanStatus = $loan['status'] ?? '';
$alreadyApproved = ($loanStatus === 'approved');
$alreadyWithdrawn = ($loanStatus === 'withdrawn');

// If loan is already approved or withdrawn, redirect to dashboard
if ($alreadyApproved) {
    header('Location: dashboard?msg=approved');
    exit;
}
if ($alreadyWithdrawn) {
    header('Location: dashboard');
    exit;
}

// If loan is in a non-payment state, redirect to loans
if (!in_array($loanStatus, ['pending_payment', 'pending'])) {
    header('Location: loans');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay Fee — <?php echo htmlspecialchars($APP_NAME); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header -->
    <div class="header">
        <a href="loans" class="back-link">&larr; Back</a>
        <h1>Pay Fee — <?php echo htmlspecialchars($APP_NAME); ?></h1>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">

            <!-- Payment Card -->
            <div class="payment-card" id="paymentCard">
                <div class="payment-icon">💳</div>
                <div class="payment-label">Processing Fee</div>
                <div class="payment-amount">KSh <?php echo number_format($loan['fee']); ?></div>

                <div class="payment-details">
                    <div class="payment-row">
                        <span class="pr-label">Loan Amount</span>
                        <span class="pr-value"><?php echo number_format($loan['amount_local']); ?> <?php echo htmlspecialchars($currencySymbol); ?></span>
                    </div>
                    <div class="payment-row">
                        <span class="pr-label">Fee</span>
                        <span class="pr-value fee">KSh <?php echo number_format($loan['fee']); ?></span>
                    </div>
                    <div class="payment-row">
                        <span class="pr-label">Loan ID</span>
                        <span class="pr-value"><?php echo htmlspecialchars($loan['id']); ?></span>
                    </div>
                </div>
            </div>

            <!-- Payment Form -->
            <div id="paymentForm" class="form-card">
                <div class="form-card-title">Enter M-Pesa Phone Number</div>
                <p style="font-size:0.82rem; color:#888; text-align:center; margin-bottom:16px;">
                    You will receive an STK push prompt on your phone
                </p>

                <div id="payError" class="alert alert-error hidden"></div>

                <div class="form-group">
                    <label for="mpesaPhone">M-Pesa Phone Number</label>
                    <div class="phone-input-wrapper">
                        <div class="phone-prefix">+254</div>
                        <input type="tel" id="mpesaPhone" placeholder="7XXXXXXXX" maxlength="9" required>
                    </div>
                </div>

                <button type="button" class="btn btn-primary" id="payBtn" onclick="initiatePayment()">
                    Pay KSh <?php echo number_format($loan['fee']); ?>
                </button>
            </div>

            <!-- Status: Pending -->
            <div class="payment-status ps-pending hidden" id="statusPending">
                <div class="ps-icon">📱</div>
                <div class="ps-title">Waiting for Payment...</div>
                <div class="ps-text">Check your phone and enter your M-Pesa PIN to complete the payment.<br>Please do not close this page.</div>
                <div style="margin-top:12px;">
                    <div class="spinner spinner-dark" style="border-color: rgba(243, 156, 18, 0.2); border-top-color: #f39c12;"></div>
                </div>
                <div style="margin-top:8px; font-size:0.75rem; color:#999;">
                    Checking payment status... <span id="pollCount">0</span>/30
                </div>
            </div>

            <!-- Status: Success -->
            <div class="payment-status ps-success hidden" id="statusSuccess">
                <div class="ps-icon">✅</div>
                <div class="ps-title">Payment Confirmed!</div>
                <div class="ps-text">Your loan has been approved. You can now withdraw your funds from the dashboard.</div>
                <a href="dashboard" class="btn btn-primary" style="margin-top:16px;">Go to Dashboard →</a>
            </div>

            <!-- Status: Error -->
            <div class="payment-status ps-error hidden" id="statusError">
                <div class="ps-icon">❌</div>
                <div class="ps-title">Payment Not Completed</div>
                <div class="ps-text" id="errorText">The payment was not completed. You can try again.</div>
                <button type="button" class="btn btn-primary" onclick="resetPayment()" style="margin-top:16px;">Try Again</button>
            </div>

        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        &copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($APP_NAME); ?>
    </div>

    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="spinner-large"></div>
        <div class="loading-text">Processing payment...</div>
    </div>

    <script>
        const loanId = <?php echo json_encode($loan_id); ?>;
        let pollingInterval = null;
        let pollCount = 0;
        const MAX_POLLS = 30;

        function showLoading(text) {
            const overlay = document.getElementById('loadingOverlay');
            overlay.querySelector('.loading-text').textContent = text || 'Processing...';
            overlay.classList.add('active');
        }
        function hideLoading() {
            document.getElementById('loadingOverlay').classList.remove('active');
        }

        function hideAllStatus() {
            document.getElementById('statusPending').classList.add('hidden');
            document.getElementById('statusSuccess').classList.add('hidden');
            document.getElementById('statusError').classList.add('hidden');
        }

        function resetPayment() {
            hideAllStatus();
            document.getElementById('paymentForm').classList.remove('hidden');
            document.getElementById('payError').classList.add('hidden');
            document.getElementById('payBtn').disabled = false;
            stopPolling();
        }

        function stopPolling() {
            if (pollingInterval) {
                clearInterval(pollingInterval);
                pollingInterval = null;
            }
            pollCount = 0;
        }

        function startPolling() {
            pollCount = 0;
            hideAllStatus();
            document.getElementById('statusPending').classList.remove('hidden');

            pollingInterval = setInterval(async () => {
                pollCount++;
                document.getElementById('pollCount').textContent = pollCount;

                if (pollCount > MAX_POLLS) {
                    stopPolling();
                    hideAllStatus();
                    document.getElementById('statusError').classList.remove('hidden');
                    document.getElementById('errorText').textContent = 'Payment timed out. The STK push may have expired. Please try again.';
                    return;
                }

                try {
                    const resp = await fetch('api/check_loan?id=' + encodeURIComponent(loanId));
                    const data = await resp.json();

                    if (data.success && data.status === 'approved') {
                        stopPolling();
                        hideAllStatus();
                        document.getElementById('statusSuccess').classList.remove('hidden');
                        return;
                    }
                    // Keep polling for pending_payment - STK might still complete on phone
                    // Do NOT stop polling on "failed" or any other status
                } catch (err) {
                    console.error('Poll error:', err);
                }
            }, 3000); // Check every 3 seconds
        }

        async function initiatePayment() {
            const phone = document.getElementById('mpesaPhone').value.trim();
            const errorEl = document.getElementById('payError');

            if (!phone) {
                errorEl.textContent = 'Please enter your M-Pesa phone number.';
                errorEl.classList.remove('hidden');
                return;
            }

            if (!/^[7]\d{8}$/.test(phone)) {
                errorEl.textContent = 'Enter a valid Safaricom number (9 digits starting with 7).';
                errorEl.classList.remove('hidden');
                return;
            }

            errorEl.classList.add('hidden');
            showLoading('Sending STK push to your phone...');
            document.getElementById('payBtn').disabled = true;

            try {
                const resp = await fetch('api/stk-push.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        loan_id: loanId,
                        phone_number: phone
                    })
                });

                const data = await resp.json();
                hideLoading();

                if (data.success) {
                    // Hide form, show pending status and start polling
                    document.getElementById('paymentForm').classList.add('hidden');
                    startPolling();
                } else {
                    errorEl.textContent = data.message || 'Payment initiation failed. Please try again.';
                    errorEl.classList.remove('hidden');
                    document.getElementById('payBtn').disabled = false;
                }
            } catch (err) {
                hideLoading();
                errorEl.textContent = 'Network error. Please check your connection and try again.';
                errorEl.classList.remove('hidden');
                document.getElementById('payBtn').disabled = false;
                console.error(err);
            }
        }
    </script>

</body>
</html>
