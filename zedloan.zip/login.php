<?php require_once 'config.php';

if (isset($_SESSION['user'])) {
    header('Location: loans');
    exit;
}

$registered = isset($_GET['registered']) && $_GET['registered'] === '1';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Login — <?php echo htmlspecialchars($APP_NAME); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="header">
    <a href="index" class="back-link">&larr; Back</a>
    <h1>Login</h1>
</div>

<div class="main-content">
    <div class="container">

        <?php if ($registered): ?>
            <div class="alert alert-success" style="margin-bottom:16px;">
                Account created! Please login.
            </div>
        <?php endif; ?>

        <form id="loginForm" onsubmit="loginUser(event)">
            <div class="form-card">
                <div class="form-card-title">Login to Your Account</div>

                <div class="form-group">
                    <label for="emailInput">Email Address</label>
                    <input type="email" id="emailInput" placeholder="e.g. john@email.com" required>
                </div>

                <div class="form-group">
                    <label for="passwordInput">Password</label>
                    <input type="password" id="passwordInput" placeholder="Enter your password" required>
                </div>

                <div id="loginError" class="alert alert-error hidden"></div>

                <button type="submit" class="btn btn-primary" id="loginBtn">
                    Login
                </button>
            </div>
        </form>

        <div class="divider">or</div>
        <a href="register" class="btn-link">Don't have an account? Register</a>

    </div>
</div>

<div class="loading-overlay" id="loadingOverlay">
    <div class="spinner-large"></div>
    <div class="loading-text" id="loadingText">Logging in...</div>
</div>

<!-- Firebase SDK v12.8.0 Modular -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-auth.js";

const firebaseConfig = <?php echo json_encode($FIREBASE_CONFIG); ?>;
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

function showLoading(text) {
    document.getElementById('loadingText').textContent = text || 'Loading...';
    document.getElementById('loadingOverlay').classList.add('active');
}
function hideLoading() {
    document.getElementById('loadingOverlay').classList.remove('active');
}
function showError(msg) {
    const el = document.getElementById('loginError');
    el.textContent = msg;
    el.classList.remove('hidden');
}

window.loginUser = async function(e) {
    e.preventDefault();

    const email = document.getElementById('emailInput').value.trim();
    const password = document.getElementById('passwordInput').value;

    if (!email || !password) {
        showError('Email and password are required.');
        return;
    }

    showError('');
    showLoading('Logging in...');
    document.getElementById('loginBtn').disabled = true;

    try {
        // 1. Firebase login
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const uid = userCredential.user.uid;
        const firebaseEmail = userCredential.user.email;

        // 2. Save/check user in PHP backend
        showLoading('Loading your data...');
        const formData = new FormData();
        formData.append('action', 'login');
        formData.append('uid', uid);
        formData.append('email', firebaseEmail);

        const resp = await fetch('api/check_auth', {
            method: 'POST',
            body: formData
        });
        const data = await resp.json();
        hideLoading();

        if (data.success) {
            window.location.href = 'loans';
        } else {
            showError(data.message || 'Login failed. Please try again.');
            document.getElementById('loginBtn').disabled = false;
        }
    } catch (error) {
        hideLoading();
        let msg = 'Login failed. Please check your credentials.';
        if (error.code === 'auth/user-not-found') msg = 'No account found with this email. Please register.';
        else if (error.code === 'auth/wrong-password') msg = 'Wrong password. Please try again.';
        else if (error.code === 'auth/invalid-email') msg = 'Invalid email address.';
        else if (error.code === 'auth/invalid-credential') msg = 'Invalid email or password.';
        else if (error.code === 'auth/network-request-failed') msg = 'Network error. Check your internet connection.';
        else if (error.code === 'auth/too-many-requests') msg = 'Too many attempts. Please wait and try again.';
        showError(msg);
        document.getElementById('loginBtn').disabled = false;
        console.error(error);
    }
};
</script>

</body>
</html>
